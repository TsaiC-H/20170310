﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class Data
    {

        private const string _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\MultiMedia_Design\ConsoleApplication1\data\drug_DB.mdf;Integrated Security=True";

        public void Createtitle(Models.Illicit_Drug Drug)
        {
            var connection = new System.Data.SqlClient.SqlConnection();
            connection.ConnectionString = _connectionString;
            connection.Open();

            var command = new System.Data.SqlClient.SqlCommand("", connection);
            command.CommandText = string.Format(@"
INSERT  INTO   Drug(Drug_Category, Drug_Name, Drug_UsualName, Drug_Class, Drug_Function, Drug_Abuse, Detailed, Picture, Picture_Text )
VALUES        (N'{0}',N'{1}',N'{2}',N'{3}',N'{4}',N'{5}',N'{6}',N'{7}',N'{8}')"
             , Drug.Drug_Category, Drug.Drug_Name, Drug.Drug_UsualName, Drug.Drug_Class, Drug.Drug_Function, Drug.Drug_Abuse, Drug.Detailed.Replace("'", "''"), Drug.Picture, Drug.Picture_Text);
            
            command.ExecuteNonQuery();

            connection.Close();
        }

        public List<Models.Illicit_Drug> ReadDrug()
        {
            var result = new List<Models.Illicit_Drug>();
            var connection = new System.Data.SqlClient.SqlConnection();
            connection.ConnectionString = _connectionString;
            connection.Open();


            var command = new System.Data.SqlClient.SqlCommand("", connection);
            command.CommandText = string.Format(@"
Select * from Drug");
            var reader = command.ExecuteReader();

            while (reader.Read())
            {
                Models.Illicit_Drug item = new Models.Illicit_Drug();
                item.Drug_Category = reader["Drug_Category"].ToString();
                item.Drug_Name = reader["Drug_Name"].ToString();
                item.Drug_UsualName = reader["Drug_UsualName"].ToString();
                item.Drug_Class = reader["Drug_Class"].ToString();
                item.Drug_Function = reader["Drug_Function"].ToString();
                item.Drug_Abuse = reader["Drug_Abuse"].ToString();
                item.Detailed = reader["Detailed"].ToString();
                item.Picture = reader["Picture"].ToString();
                item.Picture_Text = reader["Picture_Text"].ToString();
                //item.creat = reader["creat"].ToString();
                result.Add(item);
            }

            connection.Close();
            return result;
        }
    }
}