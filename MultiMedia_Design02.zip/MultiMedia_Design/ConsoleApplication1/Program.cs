﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Data.Data db = new Data.Data();
            //var Illicit_Drugs = Find_Illicit_Drugs(); //將.xml的資料讀入程式
            //InsertDrug(Illicit_Drugs);
            ShowDrug_DB(db);//將資料庫資料讀出
            Console.ReadKey();

        }

        private static void ShowDrug_DB(Data.Data db)
        {
            List<Models.Illicit_Drug> drug_get = new List<Illicit_Drug>();
            drug_get = db.ReadDrug();

            for (var j = 0; j < drug_get.Count; j++)
            {
                Console.WriteLine("類別: "+ drug_get[j].Drug_Category);
                Console.WriteLine("藥物名稱: "+ drug_get[j].Drug_Name);
                Console.WriteLine("俗名: "+ drug_get[j].Drug_UsualName);
                Console.WriteLine("分級: " + drug_get[j].Drug_Class);
                Console.WriteLine("醫療用途: " + drug_get[j].Drug_Function);
                Console.WriteLine("濫用方式: " + drug_get[j].Drug_Abuse);
                Console.WriteLine("說明: " + drug_get[j].Detailed);
                Console.WriteLine("圖片: " + drug_get[j].Picture);
                Console.WriteLine("圖片文字: " + drug_get[j].Picture_Text);
                Console.WriteLine(); Console.WriteLine();
            }
        }

        private static void InsertDrug(List<Illicit_Drug> drugs)
        {
            Data.Data db = new Data.Data();
            Console.WriteLine(string.Format("新增{0}筆資料開始", drugs.Count));
            drugs.ForEach(x =>
            {
                db.Createtitle(x);
            });
            Console.WriteLine(string.Format("新增資料結束"));
        }  

        public static List<Illicit_Drug> Find_Illicit_Drugs()
        {
            List<Illicit_Drug> illicit_Drugs = new List<Illicit_Drug>();
            var xml = XElement.Load(@"C:\Users\User\Desktop\MultiMedia_Design\常見濫用管制藥品資料集.xml"); //載入檔案
            var Illicit_Drugs_Node = xml.Descendants("rows").ToList(); //資料的節點

            for (var i = 0; i < Illicit_Drugs_Node.Count(); i++) //逐筆將資料取出
            {
                var I_D_Node = Illicit_Drugs_Node[i];
            }

            Illicit_Drugs_Node.ToList().ForEach(I_D_Node => //各<...>的名稱
            {
                var 類別 = I_D_Node.Element("類別").Value.Trim();
                var 藥物名稱 = I_D_Node.Element("藥物名稱").Value.Trim();
                var 俗名 = I_D_Node.Element("俗名").Value.Trim();
                var 分級 = I_D_Node.Element("分級").Value.Trim();
                var 醫療用途 = I_D_Node.Element("醫療用途").Value.Trim();
                var 濫用方式 = I_D_Node.Element("濫用方式").Value.Trim();
                var 說明 = I_D_Node.Element("說明").Value.Trim();
                var 圖片 = I_D_Node.Element("圖片").Value.Trim();
                var 圖片文字 = I_D_Node.Element("圖片文字").Value.Trim();

                Illicit_Drug illicit_Drug_Data = new Illicit_Drug();

                illicit_Drug_Data.Drug_Category = 類別;
                illicit_Drug_Data.Drug_Name = 藥物名稱;
                illicit_Drug_Data.Drug_UsualName = 俗名;
                illicit_Drug_Data.Drug_Class = 分級;
                illicit_Drug_Data.Drug_Function = 醫療用途;
                illicit_Drug_Data.Drug_Abuse = 濫用方式;
                illicit_Drug_Data.Detailed = 說明;
                illicit_Drug_Data.Picture = 圖片;
                illicit_Drug_Data.Picture_Text = 圖片文字;


                //Console.WriteLine(類別);
                //Console.WriteLine(藥物名稱);
                //Console.WriteLine(俗名);
                //Console.WriteLine(分級);
                //Console.WriteLine(醫療用途);
                //Console.WriteLine(濫用方式);
                //Console.WriteLine(說明);
                //Console.WriteLine(圖片);
                //Console.WriteLine(圖片文字);
                //Console.WriteLine(); Console.WriteLine();


                illicit_Drugs.Add(illicit_Drug_Data);
            });
            return illicit_Drugs;
        }
    }
}
