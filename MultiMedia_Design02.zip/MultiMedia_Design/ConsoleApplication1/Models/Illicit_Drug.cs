﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Illicit_Drug
    {

        /*<類別>中樞神經抑制劑(麻醉藥品類)</類別>
          <藥物名稱>海洛因</藥物名稱>
          <俗名>四號、白粉、細仔</俗名>
          <分級>第一級毒品</分級>
          <醫療用途>無</醫療用途>
          <濫用方式>注射吸食</濫用方式>
          <說明>
          海洛因(Heroin)之學名為二乙醯嗎啡，是由嗎啡與醋酸酐(Acetic anhydride)加熱反應而得；屬中樞神經抑制劑。吸食後最典型之感覺為興奮及欣快感，但隨之而來的是陷入困倦狀態，長期使用會產生耐受性及心理、生理依賴性，即需增加劑量才可達到主觀相同的效果，一旦停止使用，除產生戒斷反應外，心理的渴藥性是吸毒者最難克服的問題。 　　使用海洛因之副作用包括呼吸抑制、噁心、嘔吐、眩暈、精神恍惚、焦慮、搔癢、麻疹、便秘、膽管痙攣、尿液滯留、血壓降低等。部份病人會產生胡言亂語、失去方位感、運動不協調、失去性慾或性能力等現象。戒斷症狀包括渴藥、不安、打呵欠、流淚、流鼻水、盜汗、失眠、厭食、腹瀉、噁心、嘔吐、發冷、腹痛、肌肉疼痛、『冷火雞』等症狀，約經七至十天症狀會漸趨緩和。　　 海洛因之毒性為嗎啡之10倍，極易中毒，且成癮性強，戒斷症狀甚強，許多國家皆已禁止醫療使用。 濫用者常因共用針頭注射毒品或使用不潔之針頭，而感染愛滋病、病毒性肝炎(B或C型肝炎)、心內膜炎、靜脈炎等疾病。</說明>
          <圖片>網址 - 檢出Heroin_1.jpg;; 網址 - 檢出Heroin_2.jpg</圖片>
          <圖片文字>海洛因;;海洛因</圖片文字>*/

        public string Drug_Category { get; set; }
        public string Drug_Name { get; set; }
        public string Drug_UsualName { get; set; }
        public string Drug_Class { get; set; }
        public string Drug_Function { get; set; }
        public string Drug_Abuse { get; set; }
        public string Detailed { get; set; }
        public string Picture { get; set; }
        public string Picture_Text { get; set; }

    }
}
